

import UIKit

// Ice is very cold
var door = ["Ice ", "is ", "very ", "cold"]
var st = ""
/*
for i in 0...3{
    st = st + door[i]
}
print(st)
*/


let result2: String = door.reduce(st) {
    $0 + $1
}
print(result2)
